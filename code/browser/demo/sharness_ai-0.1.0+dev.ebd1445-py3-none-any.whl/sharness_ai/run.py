"""Run one command under a v0 Process Behaviour Policy.

    sharness-ai run --policy p.json [--expect-hash sha256:…] -- cmd args…

What happens, in the child, before exec:
  1. network "none": a new, empty network namespace when this process may make one
     (unshare(CLONE_NEWNET); root, or an unprivileged user namespace around it). Otherwise,
     Landlock denies every TCP bind and connect (ABI 4+). Landlock does not see UDP, so
     without a namespace DNS lookups still go out; the result says which happened.
  2. process.max_memory_mb / max_pids: RLIMIT_AS and RLIMIT_NPROC on the child, and a cgroup
     (memory.max, pids.max) when /sys/fs/cgroup is writable here (root, or a delegated subtree).
  3. prctl(PR_SET_NO_NEW_PRIVS).
  4. A Landlock ruleset: read, write and exec rights beneath the policy's paths, TCP connect
     to the policy's ports, nothing else. restrict_self() makes it final for this process
     and every descendant.

Who runs this decides what it is. Applied by a process to its own children it is a Boundary
for them and only a Setting for the process that applied it (which could have skipped it).
That is the whole argument of sharness.ai/design/policies §2, and the reason the end state is a
launcher above the agent, not a command the agent runs.
"""
import ctypes
import errno
import os
import sys

from sharness_ai import landlock, limits
from sharness_ai.policy import PolicyError, check, policy_hash

CLONE_NEWUSER = 0x10000000
CLONE_NEWNET  = 0x40000000
EXIT_REFUSED  = 125           # the policy was refused, nothing ran
EXIT_APPLY    = 126           # the policy could not be applied, nothing ran


def unavailable() -> str:
    """Why this runtime cannot enforce a policy at all, or '' if it might.

    A WebAssembly runtime (Pyodide, emscripten) has no kernel and no processes: there is no
    child to confine, so `run` and `hello` refuse there, while hashing, checking and translating
    a policy work unchanged. Landlock's absence on a real kernel is checked separately."""
    if sys.platform == "emscripten" or not hasattr(os, "fork"):
        return (f"this runtime ({sys.platform}) has no kernel and cannot start processes, so there is "
                f"no child to confine; policy hash, check and translate work here, run and hello need Linux")
    return ""


def plan(policy: dict) -> dict:
    """What `run` will do here, computed without doing it (for --verbose and for tests)."""
    abi = landlock.abi()
    net = policy.get("network")
    return {
        "landlock_abi": abi,
        "fs": abi >= 1,
        "net_namespace_try": net == "none",
        "landlock_tcp": abi >= 4,
        "ports": [] if net == "none" else list(net.get("connect_tcp_ports", [])),
        "udp_covered_without_namespace": False,
    }


def _unshare_net() -> str:
    """Try for an empty network namespace. Returns how, or '' if it could not be done."""
    lib = landlock.libc()
    if lib.unshare(CLONE_NEWNET) == 0:
        return "netns"
    if ctypes.get_errno() != errno.EPERM:
        return ""
    # unprivileged: a user namespace first, then the network namespace inside it
    if lib.unshare(CLONE_NEWUSER | CLONE_NEWNET) == 0:
        return "userns+netns"
    return ""


def apply(policy: dict) -> dict:
    """Apply the policy to the calling process. Irreversible. Returns what was applied."""
    problems = check(policy)
    if problems:
        raise PolicyError("; ".join(problems))
    applied = {"netns": "", "landlock_abi": landlock.abi(), "paths": 0, "missing": [], "ports": [], "limits": []}
    net = policy.get("network")
    if net == "none":
        applied["netns"] = _unshare_net()
    proc = policy.get("process", {})
    mem, pids = proc.get("max_memory_mb"), proc.get("max_pids")
    if mem or pids is not None:
        cg, _ = limits.cgroup(os.getpid(), mem, pids)        # the parent removes it afterwards
        applied["limits"] += cg
        applied["limits"] += limits.rlimits(mem, pids)
    rs = landlock.Ruleset(handle_net=True)
    files = policy.get("files", {})
    for p in files.get("read", []):
        if rs.add_path(p, landlock.ACCESS_READ):
            applied["paths"] += 1
        else:
            applied["missing"].append(p)
    for p in files.get("exec", []):
        if rs.add_path(p, landlock.ACCESS_EXEC):
            applied["paths"] += 1
        else:
            applied["missing"].append(p)
    for p in files.get("write", []):
        if rs.add_path(p, rs.handled_fs):
            applied["paths"] += 1
        else:
            applied["missing"].append(p)
    if net != "none" and rs.handled_net:
        for port in net.get("connect_tcp_ports", []):
            rs.add_port(port, landlock.NET_CONNECT_TCP)
            applied["ports"].append(port)
    rs.restrict_self()
    return applied


def run(policy: dict, argv: list, expect_hash: str = None, verbose: bool = False) -> int:
    """Fork, apply the policy in the child, exec argv. Returns the child's exit code."""
    h = policy_hash(policy)
    if expect_hash is not None and expect_hash != h:
        print(f"sharness-ai run: refused. The policy hashes to {h}; the hash supplied was "
              f"{expect_hash}. Nothing ran.", file=sys.stderr)
        return EXIT_REFUSED
    problems = check(policy)
    if problems:
        print("sharness-ai run: refused. The policy is not well-formed:\n  " + "\n  ".join(problems),
              file=sys.stderr)
        return EXIT_REFUSED
    if not argv:
        print("sharness-ai run: nothing to run (give a command after --)", file=sys.stderr)
        return EXIT_REFUSED
    reason = unavailable()
    if reason:
        print(f"sharness-ai run: refused. {reason}. Nothing ran.", file=sys.stderr)
        return EXIT_APPLY
    if landlock.abi() < 1:
        print("sharness-ai run: refused. Landlock is not available on this kernel, so the "
              "policy could not be enforced. Nothing ran.", file=sys.stderr)
        return EXIT_APPLY
    if verbose:
        print(f"sharness-ai run: policy {policy.get('id')} {h}; plan {plan(policy)}", file=sys.stderr)
    pid = os.fork()
    if pid == 0:                                   # child
        try:
            applied = apply(policy)
            if verbose:
                print(f"sharness-ai run: applied {applied}", file=sys.stderr)
            os.environ["SHARNESS_AI_POLICY_HASH"] = h
            os.environ["SHARNESS_AI_POLICY_ID"] = str(policy.get("id"))
            os.execvp(argv[0], argv)
        except BaseException as e:                 # noqa: BLE001 - the child must not return
            try:
                sys.stderr.write(f"sharness-ai run: could not apply the policy or start the "
                                 f"command: {e}\n")
                sys.stderr.flush()
            finally:
                os._exit(EXIT_APPLY)
    _, status = os.waitpid(pid, 0)
    proc = policy.get("process", {})
    if proc.get("max_memory_mb") or proc.get("max_pids") is not None:
        limits.remove([f"{limits.CG}/{limits.NAME}/{pid}", f"{limits.CG}/memory/{limits.NAME}/{pid}",
                       f"{limits.CG}/pids/{limits.NAME}/{pid}"])
    return os.waitstatus_to_exitcode(status)
